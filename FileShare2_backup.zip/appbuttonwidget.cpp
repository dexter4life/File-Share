#include "appbuttonwidget.h"

AppButtonWidget::AppButtonWidget(QWidget *parent) : QWidget(parent)
{

}

AppButtonWidget::~AppButtonWidget()
{

}

