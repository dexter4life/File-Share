#include "client.h"
#include "filereadwritehandler.h"

Client::Client(qintptr handle, QObject *parent) : QThread(parent)
{
    socketHandle = handle;
    clientSocket = new QTcpSocket(this);
    connect(clientSocket, SIGNAL(readyRead()), this, SLOT(readyRead()), Qt::DirectConnection);
    connect(clientSocket, SIGNAL(disconnected()), this, SLOT(disconnected()), Qt::DirectConnection);

    clientSocket->setSocketDescriptor(socketHandle);
}

void Client::disconnected()
{
    emit clientDisconnected();

    clientSocket->deleteLater();
}



void Client::writeData(QByteArray data, double size)
{
   clientSocket->write(data);
   int byte = clientSocket->bytesToWrite();
   clientSocket->flush();

    if( clientSocket->waitForBytesWritten(300))
        emit updateProgress((((double)data.size())/size)*101);
}

void Client::readyRead()
{
     QByteArray tmp;

     tmp = clientSocket->readAll();

        //check if will are sending avatar or data
      if( tmp.contains("avatar"))
      {

          QByteArray avatar;
          avatar.append(tmp);

          int nameStart = avatar.indexOf("$");
          int nameEnd = avatar.indexOf("$", nameStart+1);
          avatar.mid(nameEnd);
          QImage image = QImage::fromData(avatar.mid(nameEnd+1), "JPG");
          /// send avatar to the main thread
          emit sendAvatarInfo(QString::fromStdString(
                            avatar.mid(nameStart+1,nameEnd - nameStart-1).toStdString()),
                           QPixmap::fromImage(image),
                         QString::number(clientSocket->socketDescriptor()));
      }
}

void Client::setWriteTask(QString data)
{
   FileReadWriteHandler *fileHandler = new FileReadWriteHandler();
   fileHandler->setTask(data);
   fileHandler->setAutoDelete(true);
   connect(fileHandler, SIGNAL(sendByte(QByteArray, double)), this, SLOT(writeData(QByteArray, double )), Qt::QueuedConnection);
   //connect(fileHandler, SIGNAL(processSuccess()), this, SLOT(updateProgress(double, qint64)), Qt::QueuedConnection);

   QThreadPool::globalInstance()->start(fileHandler);
}

void Client::run()
{
    exec();
}


