#ifndef CLIENT_H
#define CLIENT_H

#include <QtCore>
#include <QtWidgets>
#include <QtNetwork>

class Client : public QThread
{
    Q_OBJECT
public:
    explicit Client(qintptr handle, QObject *parent = 0);
    ~Client() {}

   // void run();
    QTcpSocket *getSocket() { return clientSocket; }
    void task();
    void setWriteTask(QString data);
    void run();
signals:
    void sendAvatarInfo(QString name,QPixmap image,QString address);
    void clientDisconnected();
    void updateProgress(double);
public slots:
    void readyRead();
    void disconnected();
    void writeData(QByteArray data, double size);
private:
    QTcpSocket *clientSocket;
    qintptr socketHandle;
};

#endif // CLIENT_H
