#include "clientviewmodel.h"

ClientViewModel::ClientViewModel(QObject *parent)
    : QStandardItemModel(parent)
{

}

ClientViewModel::~ClientViewModel()
{

}

Qt::ItemFlags ClientViewModel::flags(const QModelIndex &index) const
{
    Q_UNUSED(index);
    return Qt::ItemIsUserCheckable | Qt::ItemIsSelectable | Qt::ItemIsEnabled;
}


