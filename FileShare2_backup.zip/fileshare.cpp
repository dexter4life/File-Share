#include <QApplication>
#include <QSystemTrayIcon>
#include <QtWidgets>
#include <QTcpSocket>
#include <QDebug>
#include <QFileDialog>
#include <iphlpapi.h>
#include <stdio.h>
#include <stdlib.h>

#include "fileserver.h"
#include "filewidget.h"
#include "fileshare.h"
#include "titlebarwidget.h"
#include "home.h"
#include "platform.h"
#include "settings.h"
#include "hotspotbutton.h"
#include "historymodel.h"
#include "historyview.h"
#include "clientinfo.h"
#include "client.h"

#include <QtNetwork>
#include "filereadwritehandler.h"

#pragma comment(lib, "IPHLPAPI.lib")

void pNotifyFunc(PWLAN_NOTIFICATION_DATA pData, PVOID pContext)
{
        reinterpret_cast<FileShare*>(pContext)->home->setWlanStatus(
                    QString::number(pData->NotificationCode));
}


FileShare::FileShare(QWidget *parent) : QWidget(parent)
  , session(0), socket(0), dataType(DATA)//for data transfer
{
    /// Initialize the history widget
    initializeHistory();
    /// Initialize most widgets
    initializeWidgets();

    userName = QString::fromStdString(Platform::getRegValue(L"FirstName") + " " +
                                      Platform::getRegValue(L"LastName"));

    userAvatar = Platform::readAccountPix(Platform::getAvatarPath());

    hClientHandle = NetOpenWlanHandle();
    WlanRegisterNotification(hClientHandle, WLAN_NOTIFICATION_SOURCE_ACM, TRUE,
                             (WLAN_NOTIFICATION_CALLBACK)pNotifyFunc, this, NULL, NULL);


}
/// connect most signals and slots
void FileShare::setConnections()
{
    connect(sysTray, &QSystemTrayIcon::activated, this, &FileShare::showWindow);
    connect(titleBar, &TitleBarWidget::moveWindow, this, &FileShare::moveWindow);
    connect(titleBar, &TitleBarWidget::minimizeWindow, this, &FileShare::minimizeWindow);
    connect(titleBar, &TitleBarWidget::closeWindow, this, &QWidget::close);
    connect(titleBar, &TitleBarWidget::displaySetting, this, &FileShare::displaySettings);
    connect(titleBar, &TitleBarWidget::displayHome, this, &FileShare::displayHome);
    connect(titleBar, &TitleBarWidget::displayRecent, this, &FileShare::displayRecent);
    connect(home, &Home::host, this, &FileShare::startHosting);
   // connect(home, &Home::startSending, this, &FileShare::startSending);
    connect(home, &Home::join, this, &FileShare::join);
    connect(settings, &Settings::showSettings, this, &FileShare::displaySettings);
    connect(hotSpot, &QAbstractButton::clicked, this, &FileShare::startHotspot);

    connect(home, &Home::ctrlOnClick, this, &FileShare::sendFolder);
    connect(home, &Home::sendFileButtonClick, this, &FileShare::sendFileOnly);
}

void FileShare::initializeHistory()
{
    recent = new historyView(this);
    recent->setGeometry(3, 60, 595, height()-60);
    recent->setVisible(false);
    recent->setColumnCount(1);
    recent->verticalHeader()->setVisible(false);
    recent->horizontalHeader()->setVisible(false);
    recent->setSelectionBehavior(QAbstractItemView::SelectRows);
}

void FileShare::initializeWidgets()
{

    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowMinimizeButtonHint );
    resize(600, 500);
    setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);


    ///initialize settings widget
    settings = new Settings(this);
    settings->resize(size());
    settings->move(2,60);
    settings->setVisible(false);

    ///Initialize hotspot button
    hotSpot = new HotspotButton(settings);
    hotSpot->setFixedSize(40,40);
    hotSpot->setText(tr("Start Hotspot"));
    hotSpot->setToolTip(tr("Start Hotspot"));
    hotSpot->setCheckable(true);
    hotSpot->move(10, 360);

    /// set system tray icon
    if( QSystemTrayIcon::isSystemTrayAvailable() )
    {
        sysTray = new QSystemTrayIcon(this);
        sysTray->setIcon(this->windowIcon());
        setTrayMenu();
    }

    titleBar = new TitleBarWidget(this);
    titleBar->setFixedSize(width(), 60);
    titleBar->move(0,0);

    home = new Home(this);
    home->resize(600, 450);
    home->move(20,50);

    setConnections();
}

void FileShare::paintEvent(QPaintEvent *e)
{
    QPainter painter(this);
    painter.save();
    QColor color(255, 255, 250);
    painter.fillRect(rect(),color);

    painter.restore();
    QWidget::paintEvent(e);
}

void FileShare::moveWindow(QPoint pos) { move(pos);}

void FileShare::displayHome()
{
    home->setVisible(true);
    settings->setVisible(false);
    recent->setVisible(false);
}

void FileShare::openSocket()
{

    socket = new QTcpSocket(this);

    if( !socket->open(QIODevice::ReadWrite)){
        QMessageBox::critical(this, tr("Socket Error"), socket->errorString(), QMessageBox::Ok);
        return;
    }

    connect(socket, &QTcpSocket::connected, this, &FileShare::sendAvatar);
    connect(socket, SIGNAL(disconnected()), home, SLOT(setJoinButtonEnable()));
}

void FileShare::join(bool state)
{
    if( state )
    {
        if( !socket )
            openSocket();

        socket->connectToHost(QHostAddress::LocalHost, D_PORT);

        if( !socket->waitForConnected(200) )
        {
            QMessageBox::critical(this, tr("Connection error"), tr("Can't connect to host, please try again"), QMessageBox::Ok);
            return;
        }
     }
}

void FileShare::sendAvatar()
{
    if( settings->canSendAvatar() )
    {
        if( socket->isOpen())
        {
            QTextStream os(socket);
            os << "avatar$" << Platform::getRegValue(L"FirstName").c_str() << " "
               << Platform::getRegValue(L"LastName").c_str()
               << "$";
            os.flush();


            QByteArray image;
            QBuffer tmpBuffer(&image);
            tmpBuffer.open(QIODevice::ReadWrite);
            tmpBuffer.seek(0);
            userAvatar.save(&tmpBuffer, "JPG");

            QDataStream ds(socket);
            ds.setByteOrder(QDataStream::LittleEndian);
            ds.writeRawData(image.data(), image.size());

            socket->flush();
        }
    }
}

QString sizePrefix(qint64 size)
{
    if(size < 1024)
        return QString("%1byte").arg(QString::number(size));
    if(size >= 1024 && size < 1048576 )
        return QString("%1KB").arg(QString::number(double(size)/1024, 'f', 2));
    if(size >= 1048576 && size < 1073741824)
        return QString("%1MB").arg(QString::number(double(size)/1048576, 'f', 2));
    return "";
}
void FileShare::displaySettings()
{
    settings->setVisible(true);
    home->setVisible(false);
    recent->setVisible(false);
}

void FileShare::startHotspot(bool state)
{
    if( state )
        settings->startWifiHotspot();
    else
        settings->stopWifiHotspot();
}

void FileShare::startHosting( bool state )
{
    if( state ) // if button is checked
    {
        server = new QTcpServer(this);
        //receive incoming avatar for a new client and set the client entry list
        connect(server, SIGNAL(sendAvatarInfo(QString,QPixmap,QString)), this,
                SLOT(setAvatarInfo(QString,QPixmap,QString )));

        connect(server, SIGNAL(networkSessionStatus(QString)), home, SLOT(setWlanStatus(QString)));

        //set the server status
        home->setWlanStatus(tr("Listening on port: %1").arg(QString::number(D_PORT)));
        //start server
        server->startServer();
    }
    else
    {
        home->setWlanStatus("Hosting stopped");
        server->pauseAccepting();
        server->close();
        server->deleteLater();
    }
}

void FileShare::minimizeWindow()
{
    if( settings->isToTray())
    {
        sysTray->show();
        sysTray->showMessage(tr("FileShare"),tr("Minimize to tray, click to restore"));
        this->hide();
    }else
        this->showMinimized();
}
void FileShare::displayRecent()
{
    recent->setVisible(true);
    home->setVisible(false);
    settings->setVisible(false);
}

void FileShare::setTrayMenu(){
    menu = new QMenu(this);
    QList< QAction *> actions;

    exit = new QAction("Exit", this);
    sendFile = new QAction("Send file",this);

    connect(exit, SIGNAL(triggered()), this, SLOT(close()));
    //connect(sendFile, SIGNAL(triggered()), this, SLOT(startSending()));

    QAction *separator = new QAction(this);
    separator->setSeparator(true);

    actions << sendFile << separator << exit;
    menu->addActions(actions);
    sysTray->setContextMenu(menu);

}
void FileShare::showWindow(QSystemTrayIcon::ActivationReason reason)
{
    switch( reason ){
    case QSystemTrayIcon::DoubleClick:
        this->show();
    }
}

void FileShare::setHistoryItem(FileWidget *widget)
{
    //Current row must be 1 less than the new (row)

    QTableWidgetItem *item = new QTableWidgetItem();
    item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);

    int row = widget->getRow();
    recent->insertRow(row);
    recent->verticalHeader()->resizeSection(row, 50);
    recent->horizontalHeader()->resizeSection(row, 600);
    recent->setCellWidget(row,0,widget);

    connect(widget, SIGNAL(buttonClicked(int)), recent, SLOT(removeRow(int)));

    this->displayRecent();
}

void FileShare::readFromFile(QString path)
{
    QFile file(path);
    if(!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::critical(this, tr("File read error:"), file.errorString(), QMessageBox::Ok);
        return;
    }

}

void FileShare::setAvatarInfo(QString name, QPixmap image, QString address)
{
    /// change is possible in the next version
    home->setUserInformation(name, image, address);
}


void FileShare::showJoinMessage(bool value)
{
    if( !value ){
        QMessageBox::critical(this, tr("Socket Error"), tr("Can't find host to connect to"));
        return;
    }
}

void FileShare::sendFolder()
{
    QStringList filesList;
    filesList << QFileDialog::getExistingDirectory(this, QApplication::applicationName(), QDir::currentPath());


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void FileShare::sendFileOnly()
{
    QStringList filesList = QFileDialog::getOpenFileNames(this, QApplication::applicationName(), QDir::currentPath());

    /// instantiate a multi-threaded event to handle file sending
    int row = 0;
    foreach(Client *client, server->clients())
    {
        foreach( QString file, filesList)
        {
            FileWidget *fileWidget = new FileWidget(file,row++, recent);
            connect(client, SIGNAL(updateProgress(double)), fileWidget, SLOT(updateProgressBar(double)));
            setHistoryItem(fileWidget);
            client->setWriteTask(file);

        }
    }

}

void FileShare::deleteSocket() { home->setJoinButtonEnable(); }
