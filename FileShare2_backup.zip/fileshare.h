#ifndef FILESHARE_H
#define FILESHARE_H

#include <QWidget>
#include <QSystemTrayIcon>
#include <QListView>
#include <QHostAddress>
#include "WlanInterface.h"
#include <QThread>
#include <QTcpServer>

QT_BEGIN_NAMESPACE
class QGridLayout;
class QNetworkSession;
class TitleBarWidget;
class Home;
class Settings;
class HotspotButton;
class QMenu;
class HistoryModel;
class historyView;
class fileServer;
class QTcpSocket;
class FileWidget;
QT_END_NAMESPACE

enum DataType
{
    AVATAR = 0x13,
    DATA
};

class FileShare : public QWidget
{
    Q_OBJECT
public:
    Settings *settings;
    Home *home;

    explicit FileShare(QWidget *parent = 0);
    ~FileShare(){ }

    virtual void paintEvent(QPaintEvent *e);
    void setTrayMenu();
    void setConnections();
    void initializeHistory();
    void initializeWidgets();
    void readFromFile(QString path);

    // open socket for connecting to server
    void openSocket();

public slots:
    void join(bool state);
    void sendAvatar();
    void moveWindow(QPoint pos);
    void displayHome();
    void displaySettings();
    void startHotspot(bool state);
    void startHosting(bool state);
    void minimizeWindow();
    void showWindow(QSystemTrayIcon::ActivationReason reason);
    void displayRecent();
    void setHistoryItem(FileWidget *widget);
    void deleteSocket();
    void showJoinMessage(bool value);
    void sendFolder();
    void sendFileOnly();
    void setAvatarInfo(QString name, QPixmap image, QString address);
private:
     QSystemTrayIcon *sysTray;
     TitleBarWidget *titleBar;
     HotspotButton *hotSpot;
     QMenu *menu;
     QAction *exit, *sendFile;
     HistoryModel *model;
     historyView *recent;
     QString sizePrefix(qint64 size);
     QTcpSocket *socket;
     QTcpServer *server; //remove
     QStringList data;
     QPixmap userAvatar;
     QString userName;
     QList < QTcpSocket * > clients;
     QNetworkSession *session;
     HANDLE hClientHandle;
     DataType dataType;
signals:
     void setJoinButtonChecked(bool state);
};

#endif // FILESHARE_H
