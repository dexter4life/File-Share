#include "filewidget.h"
#include <QFileIconProvider>
#include <QtWidgets>
#include "customExitButton.h"

void FileWidget::setWidgetInformation(QString path)
{
    QFileInfo file(path);
    setToolTip(path);
    setFileIcon(path);
    setFileName(file.fileName());
    setFileSize(sizePrefix(file.size()));
}

FileWidget::FileWidget(QString path, int row, QWidget *parent) : QWidget(parent)
{
    setFixedSize(588, 50);

    progress = 0;

    CustomExitButton *msg = new CustomExitButton(this);
    msg->setFixedSize(15,15);

    setRow(row);

    iconImage = new QLabel(this);

    fileName = new QLabel(this);
    fileName->setFixedWidth(300);
    fileName->move(50, 2);

    fileSize = new QLabel(this);
    fileSize->move(50,20);

    QGridLayout *layout = new QGridLayout(this);
    layout->setHorizontalSpacing(1);

    progressBar = new QProgressBar(this);
    progressBar->setFixedHeight(3);
    progressBar->setMaximum(100);
    progressBar->setGeometry(x(),height()-2, width(), 1);
    progressBar->setTextVisible(false);
    progressBar->setValue(progress); //make sure with start counting from zero

    layout->addWidget(msg, 0, 3, Qt::AlignRight | Qt::AlignTop);
    layout->addWidget(iconImage, 0, 0, Qt::AlignLeft | Qt::AlignCenter);

    setWidgetInformation(path);

    connect(msg, SIGNAL(clicked()), this, SLOT(triggered()));
}

FileWidget::~FileWidget()
{

}

void FileWidget::setFileName(QString name) { fileName->setText(name); }

void FileWidget::setFileSize(QString size) { fileSize->setText("size: " + size); }

//void FileWidget::setFileRate(QString r) { rate->setText(r); }

void FileWidget::setFileIcon(QString iconPath)
{
    QFileIconProvider iconProvider;
    QIcon icon = iconProvider.icon(QFileInfo(iconPath));
    iconImage->setPixmap(icon.pixmap(iconImage->size()));
}
void FileWidget::triggered()
{
    emit buttonClicked(row);
}

void FileWidget::updateProgressBar(double value)
{
    progress += value;

    progressBar->setValue((int)progress);

   // if( (int)tmp == 101 )  tmp = 0;
}
QString FileWidget::sizePrefix(qint64 size)
{
    if(size < 1024)
        return QString("%1byte").arg(QString::number(size));
    if(size >= 1024 && size < 1048576 )
        return QString("%1KB").arg(QString::number(double(size)/1024, 'f', 2));
    if(size >= 1048576 && size < 1073741824)
        return QString("%1MB").arg(QString::number(double(size)/1048576, 'f', 2));
    return "";
}
