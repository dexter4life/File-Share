#ifndef FILEWIDGET_H
#define FILEWIDGET_H

#include <QWidget>
#include <QProgressBar>
#include <QLabel>

class FileWidget : public QWidget
{
    Q_OBJECT
public:
    explicit FileWidget(QString path, int row, QWidget *parent);
    ~FileWidget();

    inline void setRow(int r) {row = r;}
    inline int getRow() const { return row; }

    void setFileIcon(QString iconPath);
    void setFileName(QString name);
    void setFileSize(QString size);
    QString sizePrefix(qint64 size);

public slots:
    void setWidgetInformation(QString path);
    void triggered();
    void updateProgressBar(double value);
signals:
    void buttonClicked(int row);

private:
    int row;
    QLabel *iconImage, *fileName, *fileSize;
    QProgressBar *progressBar;
    double progress;
};

#endif // FILEWIDGET_H
