#include "historymodel.h"
#include <QFileIconProvider>

HistoryModel::HistoryModel(QObject *parent)
    : QStandardItemModel(parent)
{

}

HistoryModel::~HistoryModel()
{

}

Qt::ItemFlags HistoryModel::flags(const QModelIndex &index) const
{
    Q_UNUSED(index);
    return Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDropEnabled;
}



