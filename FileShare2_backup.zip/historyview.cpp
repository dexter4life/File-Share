#include "historyview.h"
#include <QtWidgets>
#include <QtCore>

historyView::historyView(QWidget *parent)
    : QTableWidget(parent)
{
    menu = new QMenu(this);

    QList< QAction * > actions;

    send = new QAction(QIcon(":/image/send-file-128.png"),"Send",menu);
    del = new QAction(QIcon(":/image/delete-512.png"),"Delete", menu);

    // connections here

   // connect(del, SIGNAL(triggered()), this, SLOT(deleteRow()));
    connect(send, SIGNAL(triggered()), this, SIGNAL(sendFile()));

    actions << send << del;
    menu->addActions(actions);
}

historyView::~historyView(){}

void historyView::contextMenuEvent(QContextMenuEvent *event)
{
    if( event->isAccepted())
    {
        menu->exec(event->globalPos());
    }
}


