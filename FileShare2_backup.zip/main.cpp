#include <QApplication>
#include "fileshare.h"
#include <QStyleFactory>
#include <QException>
#include <QMessageBox>

int main(int argc, char *argv[]){
    QApplication a(argc, argv);
    a.setWindowIcon(QIcon(":/image/Share.png"));

    a.setStyle(QStyleFactory::create("fusion"));
    FileShare window;
    window.show();
    return a.exec();
}
