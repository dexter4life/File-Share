#include <QtWidgets>
#include "netwokselectionbox.h"

#include <QSignalMapper>

NetwokSelectionBox::NetwokSelectionBox(QWidget *parent)
    : QComboBox(parent)
{
    connect(this, SIGNAL(activated(int)), this, SLOT(remit(int)));
}

NetwokSelectionBox::~NetwokSelectionBox()
{

}

void NetwokSelectionBox::mousePressEvent(QMouseEvent *e)
{


    beforeIndex  = currentIndex();

    QComboBox::mousePressEvent(e);
}

void NetwokSelectionBox::remit(int item)
{
    if( beforeIndex != item)
    {
        emit beforeCurrent(beforeIndex);
    }
}
