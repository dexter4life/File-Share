#include "sendfilebutton.h"
#include <QtWidgets>

SendFileButton::SendFileButton(QWidget *parent)
    : QPushButton(parent)
{

}

SendFileButton::~SendFileButton()
{

}

void SendFileButton::mousePressEvent(QMouseEvent *event)
{

   if( event->isAccepted() )
    {
        if( event->button() == Qt::LeftButton )
        {
           if( event->modifiers().testFlag(Qt::ControlModifier) )
               emit ctrlOnClick(); /// control key pressed
        }

        QPushButton::mousePressEvent(event);
    }
}

