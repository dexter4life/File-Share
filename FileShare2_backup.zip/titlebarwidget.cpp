#include "titlebarwidget.h"
#include "minimizebutton.h"
#include "customExitButton.h"
#include "buttonset.h"

#include <QtWidgets>
#include <QtGui>

TitleBarWidget::TitleBarWidget(QWidget *parent) : QWidget(parent)
{
    setAcceptDrops(false);
    m_Minimize = new MinimizeButton(this);
    m_Minimize->setFixedSize(17,17);
    m_Minimize->move(550, 10);

    exitButton = new CustomExitButton(this);
    exitButton->setFixedSize(17,17);
    exitButton->move(570, 10);


    QLabel *label = new QLabel(this);
    label->setFont(QFont("Calisto MT", 20, QFont::Bold, true));
    label->setText("File Share");
    label->setBackgroundRole(QPalette::BrightText);
    label->setStyleSheet(QStringLiteral("QLabel {color: white}"));
    label->move(70,10);

    QWidget *logo = new QWidget(this);
    logo->setFixedSize(50,50);
    logo->setStyleSheet(QStringLiteral("QWidget { image: url(:/image/share-icon.png); }"));
    logo->move(5,5);

    connect(m_Minimize, SIGNAL(clicked()), this, SIGNAL(minimizeWindow()));
    connect(exitButton, SIGNAL(clicked()), this, SIGNAL(closeWindow()));

    buttons = new ButtonSet(this);
    buttons->setFixedWidth(200);
    buttons->move(200, 1);
    connect(buttons, SIGNAL(settingClicked()), this, SIGNAL(displaySetting()));
    connect(buttons, SIGNAL(homeButtonClicked()), this, SIGNAL(displayHome()));
    connect(buttons, SIGNAL(recentButtonClicked()), this, SIGNAL(displayRecent()));
}

TitleBarWidget::~TitleBarWidget()
{

}

void TitleBarWidget::paintEvent(QPaintEvent *e)
{

    QPainter painter(this);
    painter.save();
    painter.drawImage(rect(),QImage(":/image/background.jpg"));
    painter.restore();
    QWidget::paintEvent(e);
}

void TitleBarWidget::mouseMoveEvent(QMouseEvent *e)
{
    if( m_draged){
        emit moveWindow(e->globalPos() - m_dragPos );
        e->accept();
    }
}

void TitleBarWidget::mouseReleaseEvent(QMouseEvent *e)
{
    Q_UNUSED(e);
    m_draged = false;
}

void TitleBarWidget::mousePressEvent(QMouseEvent *e)
{
    if( e->button() == Qt::LeftButton){
        m_draged = true;
        m_dragPos = e->globalPos() - this->mapToGlobal(pos());
        e->accept();
    }
}

